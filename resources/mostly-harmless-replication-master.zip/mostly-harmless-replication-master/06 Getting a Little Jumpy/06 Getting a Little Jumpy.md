# 06 Getting a Little Jumpy
## 6.1 Sharp RD

### Figure 6-1-1

Completed in [Stata](Figure%206-1-1.do), [R](Figure%206-1-1.r), [Python](Figure%206-1-1.py) and [Julia](Figure%206-1-1.jl)

![Figure 6-1-1 in Stata](https://github.com/vikjam/mostly-harmless-replication/blob/master/06%20Getting%20a%20Little%20Jumpy/Figure%206-1-1-Stata.png?raw=true)

### Figure 6-1-2

Completed in [Stata](Figure%206-1-2.do), [R](Figure%206-1-2.r), [Python](Figure%206-1-2.py) and [Julia](Figure%206-1-2.jl)

![Figure 6-1-2 in R](https://github.com/vikjam/mostly-harmless-replication/blob/master/06%20Getting%20a%20Little%20Jumpy/Figure%206-1-2-R.png?raw=true)

### Figure 6-2-1

Completed in [Stata](Figure%206-2-1.do), [R](Figure%206-2-1.r), [Python](Figure%206-2-1.py) and [Julia](Figure%206-1-1.jl)

![Figure 6-2-1 in Julia](https://github.com/vikjam/mostly-harmless-replication/blob/master/06%20Getting%20a%20Little%20Jumpy/Figure%206-2-1-Julia.png?raw=true)
