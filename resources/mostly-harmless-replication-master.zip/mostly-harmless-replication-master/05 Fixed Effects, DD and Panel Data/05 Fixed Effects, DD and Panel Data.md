# 05 Fixed Effects, DD and Panel Data
## 5.2 Differences-in-differences

### Figure 5-2-4

Completed in [Stata](Figure%205-2-4.do), [R](Figure%205-2-4.r), [Python](Figure%205-2-4.py) and [Julia](Figure%205-2-4.jl).

![Figure 5-2-4 in Stata](https://github.com/vikjam/mostly-harmless-replication/blob/master/05%20Fixed%20Effects,%20DD%20and%20Panel%20Data/Figure%205-2-4-Stata.png?raw=true)
