install.packages(c("ROCR","class","rpart")) #Needed packages

####################################
###CHOOSING AND EVALUATING MODELS###
####################################

##Evaluating classification models

#Building and applying a logistic regression spam model 

spamD <- read.table('spamD.tsv',header=T,sep='\t') #Don't forget to set your working directory
spamTrain <- subset(spamD,spamD$rgroup>=10) #Defining a training sample
spamTest <- subset(spamD,spamD$rgroup<10) #Defining a testing sample
spamVars <- setdiff(colnames(spamD),list('rgroup','spam')) #Create a vector of variable names of independent variables, i.e. to be used in the model
spamFormula <- as.formula(paste('spam=="spam"', #Create a formula
                                paste(spamVars,collapse=' + '), sep=' ~ '))
spamModel <- glm(spamFormula,family=binomial(link='logit'), #Estimate the logit model (we leave the details to the later weeks)
                 data=spamTrain)
spamTrain$pred <- predict(spamModel,newdata=spamTrain, #Get predictions (fitted values) for the training sample
                          type='response')
spamTest$pred <- predict(spamModel,newdata=spamTest, #Get predictions for the testing sample
                         type='response')

#Spam classifications
sample <- spamTest[c(7,35,224,327),c('spam','pred')] #Look at some specific observations
print(sample)

#Spam confusion matrix
cM <- table(truth=spamTest$spam,prediction=spamTest$pred>0.1) #Threshold of 0.5
print(cM)

##Evaluating probability models

#Plotting the receiver operating characteristic curve

library('ROCR') #Includes ROC and AUC
eval <- prediction(spamTest$pred,spamTest$spam) #For the ROCR function, specify the predictions and true outcomes
?performance
plot(performance(eval,"tpr","fpr")) #ROCR function, specify prediction object and specific measures
print(attributes(performance(eval,'auc'))$y.values[[1]]) #AUC, rather non-standard notation

#Calculating log likelihood
sum(ifelse(spamTest$spam=='spam', #Log-likelihood
           log(spamTest$pred),
           log(1-spamTest$pred)))
sum(ifelse(spamTest$spam=='spam', #Log-likelihood rescaled by the number of observations
           log(spamTest$pred),
           log(1-spamTest$pred)))/dim(spamTest)[[1]]

#Computing the null model's log likelihood
pNull <- sum(ifelse(spamTest$spam=='spam',1,0))/dim(spamTest)[[1]] #Unconditional probability of being spam
#pNull <- mean(spamTest$spam=='spam')
sum(ifelse(spamTest$spam=='spam',1,0))*log(pNull) +
  sum(ifelse(spamTest$spam=='spam',0,1))*log(1-pNull) #Log-likelihood based on the previous probability

##Other measures of fit

#Log-likelihood as a function
LL<-function(outcome,prediction,hit="spam"){
  sum(ifelse(outcome==hit,log(prediction),log(1-prediction)))
}
LL(spamTest$spam,spamTest$pred,"spam") #Just checking it is the same as in the previous case
LL(spamTest$spam,pNull,"spam") #Checking the null model

#Goodness-of-fit
McFadden_R2<-function(outcome,prediction,hit="spam"){
  1-LL(outcome,prediction,hit=hit)/LL(outcome,sum(outcome==hit)/length(outcome))
}
McFadden_R2(spamTest$spam,spamTest$pred)

#Information criteria
AIC<-function(outcome,prediction,hit="spam",k){
  2*k-2*LL(outcome,prediction,hit=hit)
}
HQC<-function(outcome,prediction,hit="spam",k){
  2*k*log(log(length(outcome)))-2*LL(outcome,prediction,hit=hit)
}
BIC<-function(outcome,prediction,hit="spam",k){
  k*log(length(outcome))-2*LL(outcome,prediction,hit=hit)
}

ICs<-list(AIC=c(AIC(spamTest$spam,spamTest$pred,k=length(spamVars))),
          HQC=c(HQC(spamTest$spam,spamTest$pred,k=length(spamVars))),
          BIC=c(BIC(spamTest$spam,spamTest$pred,k=length(spamVars))))
          
ICs

##########################
###MEMORIZATION METHODS###
##########################

##KDD and KDD Cup 2009 dataset

#Preparing the KDD data for analysis

#Read the file of independent variables. Treat both NA and the empty string as missing data.
d<-read.table("orange_small_train.data",header=TRUE,sep="\t",na.strings=c("NA",""), 
              stringsAsFactors=FALSE)
head(d)

#Read churn dependent variable and add it to the dataset
churn<-read.table("orange_small_train_churn.labels.txt",header=FALSE,sep="\t")
d$churn<-churn$V1

#Add appetency as a new column. 
appetency<-read.table("orange_small_train_appetency.labels.txt",header=F,sep="\t")
d$appetency<-appetency$V1
#Add upselling as a new column. 
upselling<-read.table("orange_small_train_upselling.labels.txt",header=F,sep="\t")
d$upselling<-upselling$V1

#By setting the seed to the pseudo-random number generator,
#we make our work reproducible: someone redoing it will see the exact same results.
#This is not necessary but surely "polite".
set.seed(729375)

#Split data into training and testing subsets.
d$rgroup<-runif(dim(d)[1]) #Random variable rgroup is used as a splitting factor
dTrainAll<-subset(d,rgroup<=0.9)  # Set for building models and impact coding
dTest<-subset(d,rgroup>0.9) # Set for evaluation

#Specify the outcomes
outcomes<-c("churn","appetency","upselling")

#Creating object made of independent variables (in the training sample) only.
vars<-setdiff(colnames(dTrainAll),c(outcomes,"rgroup")) #Difference between sets
print(vars)

#Identify which features are categorical variables. 
catVars<-vars[sapply(dTrainAll[,vars],class) %in% c("factor","character")] #sapply() forces a vector to be returned
#Identify which features are numeric variables. 
numericVars<-vars[sapply(dTrainAll[,vars],class) %in% c("numeric","integer")]

#Remove unneeded objects from workspace 
#(they are already parts of other objects and we don't need the whole sample again).
rm(list=c("d","churn","appetency","upselling"))

#Specify essential features of the model/procedure.
#Choose which outcome to model (we focus only of the churn variable from now on).
outcome<-"churn"
#Choose which outcome is considered positive. 
pos<-"1"

#Further split training data into training and calibration (50/50 split).
useForCal<-rbinom(n=dim(dTrainAll)[1],size=1,prob=0.5)>0 #This can be considered as an alternative to the rgroup approach above.
#head(useForCal,100)
length(useForCal[useForCal==TRUE])/length(useForCal) #Checking the split ratio
length(useForCal[useForCal==FALSE])/length(useForCal) #Checking the split ratio
#Select (subset) only such rows of dTraiAll for which useForCal is TRUE (logical subsetting).
dCal<-subset(dTrainAll,useForCal)
#dCal1<-dTrainAll[useForCal,] #Alternative without the subset() command
#setdiff(dCal,dCal1)
#Select (subset) only such rows of dTraiAll for which useForCal is not TRUE
dTrain<-subset(dTrainAll,!useForCal) 
#dTrain1<-dTrainAll[!useForCal,] #Alternative without the subset() command
#head(dTrain) #See the row labels/numbers

#Now we have loaded the data, added dependent variabels, 
#split the dataset into training and testing samples, and specified
#the dependent variable of interest as well as its value of modeling interest.
#We are thus ready for the analysis.

##Building single-variable models

#Using categorical features

#Plotting churn grouped by variable 218 levels
table218<-table(
  Var218=dTrain[,"Var218"], #Tabulate levels of Var218.
  churn=dTrain[,outcome], #Tabulate levels of churn outcome.  
  useNA="ifany") #Include NA values in tabulation. 
print(table218) #NA level seems informative
print(table218[,2]/(table218[,1]+table218[,2])) #Churn rates grouped by variable 218 codes

#Given a vector of training outcomes (outCol), 
#a categorical training variable (varCol), and a prediction variable (appCol), 
#use outCol and varCol to build a single-variable model
#and then apply the model to appCol to get new predictions.

#Try the function in steps
catVars #Check all categorical variables
v="Var218" #Specify one
outCol=dTrain[,outcome] #Specify the training set for the dependent variable (churn rate)
varCol=dTrain[,v] #Specify the training set for the independent variable (the "v" object)
appCol=dTest[,v] #Specify the testing set for the independent variable (the "v" object)

mkPredC<-function(outCol,varCol,appCol) {
  #Get unconditional probability of the outcome variable being positive
  pPos<-sum(outCol==pos)/length(outCol)
  #Get conditional probability of the outcome variable being positive given the variable has NA value
  naTab<-table(as.factor(outCol[is.na(varCol)])) #Using table() to get the NA counts
  pPosWna<-(naTab/sum(naTab))[pos] #Get the probability
  #Smoothing operator is added due to possible zero probabilities
  smoothingEpsilon<-1.0e-3 
  #Get conditional probabilities of the outcome variable being positive given the independent variable levels
  vTab<-table(as.factor(outCol),varCol)
  pPosWv<-(vTab[pos,]+smoothingEpsilon*pPos)/(colSums(vTab)+smoothingEpsilon) 
  #Make predictions
  pred<-pPosWv[appCol]   #By looking up a specific level of the independent variabl
  pred[is.na(appCol)]<-pPosWna   #Add in predictions for NA levels of appCol. 
  pred[is.na(pred)]<-pPos    #Add in predictions for levels of appCol that weren't known during training (uncoditional probability).
  pred #Return vector of predictions.
}

#Applying single-categorical variable models to all of our datasets (training, calibration and testing)
#This returns predictions for all categorical variables and adds them to the specified dataset
for(v in catVars) {
  pi<-paste("pred",v,sep="") #Specify the prediction of the i-th variable (p_i)
  dTrain[,pi]<-mkPredC(dTrain[,outcome],dTrain[,v],dTrain[,v]) #Add a new column (of predictions) to dTrain
  dCal[,pi]<-mkPredC(dTrain[,outcome],dTrain[,v],dCal[,v]) #Add a new column (of predictions) to dCal
  dTest[,pi]<-mkPredC(dTrain[,outcome],dTrain[,v],dTest[,v]) #Add a new column (of predictions) to dTest
}
#head(dTrain)
#head(dCal)
#head(dTest)

#Scoring categorical variables by AUC (area under curve)
calcAUC<-function(predcol,outcol) { 
  #"predcol" represent the predictions and "outcol" represents the actual outcomes
  #these are then fed to the prediction function
  perf<-performance(prediction(predcol,outcol==pos),"auc") #In the ROCR package
  #performance() function returns an S4 object which uses @ instead of $
  as.numeric(perf@y.values)
}

for(v in catVars) {
  #Specify the prediction of the i-th variable (p_i)
  pi<-paste("pred",v,sep="") 
  #get AUC for the training set
  aucTrain<-calcAUC(dTrain[,pi],dTrain[,outcome]) 
  #Check the performance only for variables with training performance over a specific threshold
  if(aucTrain>=0.65) {
    aucCal<-calcAUC(dCal[,pi],dCal[,outcome]) #get AUC for the calibration set
    print(paste(pi,"trainAUC:",round(aucTrain,4),"calibrationAUC:",round(aucCal,4)),quote=FALSE)
  }
}

#Using numeric features

#Try the "mkPredN" function in steps
numericVars
v="Var1"
outCol=dTrain[,outcome]
varCol=dTrain[,v]
appCol=dTest[,v]

#Single-numeric models
mkPredN<-function(outCol,varCol,appCol) {
  nval<-length(unique(varCol[!is.na(varCol)])) #Finds the number of unique values
  if(nval<=1) { #If there's only one or none unique value
    pPos<-sum(outCol==pos)/length(outCol) #Fraction of positive outcomes, i.e. constant probability
    return(pPos+numeric(length(appCol))) #Returns a vector (of length appCol) of probability pPos
  }
  #Find active thresholds for specified quantiles
  cuts<-unique(as.numeric(quantile(varCol,probs=seq(0, 1, 0.1),na.rm=T)))
  varC<-cut(varCol,cuts) #Assigns values into intervals given by "cuts"
  #head(varC,100)
  appC<-cut(appCol,cuts) #Assigns values into intervals given by "cuts"
  #head(appC,100)
  #Now the dataset is practically translated into the character case so that we can use the mkPredC() function
  mkPredC(outCol,varC,appC)
}

for(v in numericVars) { #Parallel to the character case
  pi<-paste("pred",v,sep="")
  dTrain[,pi]<-mkPredN(dTrain[,outcome],dTrain[,v],dTrain[,v])
  dTest[,pi]<-mkPredN(dTrain[,outcome],dTrain[,v],dTest[,v])
  dCal[,pi]<-mkPredN(dTrain[,outcome],dTrain[,v],dCal[,v])
  aucTrain<-calcAUC(dTrain[,pi],dTrain[,outcome])
  if(aucTrain>=0.55) { #We set lower threshold as we do not suspect much overfitting for numeric models
    aucCal<-calcAUC(dCal[,pi],dCal[,outcome])
    print(paste(pi,"trainAUC:",round(aucTrain,4),"calibrationAUC:",round(aucCal,4)),quote=FALSE)
  }
}

#Running a repeated cross-validation experiment
v<-"Var217" #Pick a variable
pi<-paste("pred",v,sep="")
auc0<-calcAUC(dCal[,pi],dCal[,outcome])
aucs<-rep(NA,100) #Create an empty vector (full of NAs)
for(rep in 1:length(aucs)) { #For 100 iterations...
  #...select a random subset of about 10% of the training data as hold-out set,...
  useForCalRep<-rbinom(n=dim(dTrainAll)[[1]],size=1,prob=0.1)>0 
  #...use the random 90% of training data to train model and evaluate that model on hold-out set,...
  predRep<-mkPredC(dTrainAll[!useForCalRep,outcome], 
                   dTrainAll[!useForCalRep,v],
                   dTrainAll[useForCalRep,v])
  #...calculate resulting model's AUC using hold-out set; store that value and repeat.
  aucs[rep]<-calcAUC(predRep,dTrainAll[useForCalRep,outcome])
}
validation<-c(auc0,mean(aucs),sd(aucs))
names(validation)<-c("Original AUC","Mean AUC","AUC SD")
validation

##Building models with many variables

#Variable selection
#We select variables which are better than a coin flip based on the log likelihood
selVars<-c() #Create an empty vector
#selVars
minStep<-25 #Set a threshold for a good-enough improvement
outCol<-dCal[,outcome] #Specify the dataset section
#Find the benchmark L0 (the same for all variables)

L0_benchmark<-LL(outCol,sum(outCol==pos)/length(outCol),hit=pos) 

#Run through all categorical variables and select only the ones
#which have higher LL than L0 (by a specified margin)
for(v in catVars) {
  pi<-paste('pred',v,sep='')
  #Increase in the log-likelihood compared to the based model
  #Sometimes referred to as the deviance
  liCheck<-2*((LL(dCal[,outcome],dCal[,pi],hit=pos)-L0_benchmark))
  if(liCheck>minStep) { #If the increase is higher than the threshold,...
    print(paste(pi,", calibrationScore: ",round(liCheck,4),sep=""),quote=FALSE) #...print it out...
    selVars <- c(selVars,pi) #...and add it the "selVars"
  }
}
selVars

#Repeat for the numeric variables
for(v in numericVars) {
  pi<-paste('pred',v,sep='')
  liCheck<-2*((LL(dCal[,outcome],dCal[,pi],hit="1")-L0_benchmark))
  if(liCheck>=minStep) {
    print(paste(pi,", calibrationScore: ",round(liCheck,4),sep=""),quote=FALSE)
    selVars <- c(selVars,pi)
  }
}

length(selVars)
selVars

#Building decision trees
library("rpart") #With an in-build rpart() function

#Building a bad decision tree
tVars <- paste('pred',c(catVars,numericVars),sep='') #Using all our variables
fV <- paste(outcome,'>0 ~ ',paste(tVars,collapse=' + '),sep='') #Writing down the model
tmodel1 <- rpart(fV,data=dTrain)
print(calcAUC(predict(tmodel1,newdata=dTrain),dTrain[,outcome])) #Over-fitting
print(calcAUC(predict(tmodel1,newdata=dTest),dTest[,outcome]))
print(calcAUC(predict(tmodel1,newdata=dCal),dCal[,outcome]))

#Another bad decision tree
?rpart.control()
tmodel2 <- rpart(fV,data=dTrain,
                control=rpart.control(cp=0.001,minsplit=1000, #With specific parameters
                                      minbucket=1000,maxdepth=5)
)
print(calcAUC(predict(tmodel2,newdata=dTrain),dTrain[,outcome])) #Over-fitting
print(calcAUC(predict(tmodel2,newdata=dTest),dTest[,outcome]))
print(calcAUC(predict(tmodel2,newdata=dCal),dCal[,outcome]))

#A better decision tree
f <- paste(outcome,'>0 ~ ',paste(selVars,collapse=' + '),sep='') #Using only the selected variables
tmodel3 <- rpart(f,data=dTrain,
                control=rpart.control(cp=0.001,minsplit=1000,
                                      minbucket=1000,maxdepth=5)
)
print(calcAUC(predict(tmodel3,newdata=dTrain),dTrain[,outcome]))
print(calcAUC(predict(tmodel3,newdata=dTest),dTest[,outcome]))
print(calcAUC(predict(tmodel3,newdata=dCal),dCal[,outcome]))

tmodel_def <- rpart(f,data=dTrain) #Checking for the default parameter setting
print(calcAUC(predict(tmodel_def,newdata=dTrain),dTrain[,outcome]))
print(calcAUC(predict(tmodel_def,newdata=dTest),dTest[,outcome]))
print(calcAUC(predict(tmodel_def,newdata=dCal),dCal[,outcome]))

#Printing and plotting the decision tree
print(tmodel3)
par(cex=0.7)
#plot(tmodel1)
#text(tmodel1)
#plot(tmodel2)
#text(tmodel2)
plot(tmodel3)
text(tmodel3)

#k-nearest neighbor methods
library("class")
nK<-10 #Number of neighbors
knnTrain<-dTrain[,selVars] #Specify the variables used for training
knnCl<-dTrain[,outcome]==pos #Specifify the vector of known training outcomes
knnPred<-function(testingSet) { #Here, we only specify testingSet, i.e. a set on which we test
  knnDecision<-knn(knnTrain,testingSet,knnCl,k=nK,prob=T,use.all=T) 
  #prob=T yields probabilities from the model to be saved in the final object
  #use.all=T/F controls ties (this might cause problems in specific cases)
  #knn_check<-knn(knnTrain,dTrain[,selVars],knnCl,k=nK,prob=T,use.all=T)
  ifelse(knnDecision==TRUE, #Transform the knn output into probabilities
         attributes(knnDecision)$prob,
         1-(attributes(knnDecision)$prob))
}
print(calcAUC(knnPred(dTrain[,selVars]),dTrain[,outcome]))
print(calcAUC(knnPred(dCal[,selVars]),dCal[,outcome]))
print(calcAUC(knnPred(dTest[,selVars]),dTest[,outcome]))

#Naive Bayes
#Check the function step-by-step
pVars<-paste("pred",c(numericVars,catVars),sep="") #all variables...
pf<-dTrain[,pVars] #...from the dTrain subset

#Get the unconditional probabilty of a success
pPos<-sum(dTrain[,outcome]==pos)/length(dTrain[,outcome]) 
#Function using the uncoditional prob. and a set of outcomes from a given set
nBayes<-function(pPos,pf) { 
  #Get the unconditional probabilty of a failure
  pNeg<-1-pPos
  #Set the smoothing operator
  smoothingEpsilon<-1.0e-5
  #Using conditional probability definition and the smoothing operator,
  #we find the positive score (using the trick described in the presentation)
  scorePos<-log(pPos+smoothingEpsilon) + 
    rowSums(log(pf/pPos+smoothingEpsilon))
  #And parallel for the negative score
  scoreNeg<-log(pNeg+smoothingEpsilon) +
    rowSums(log((1-pf)/(1-pPos) + smoothingEpsilon))
  m<-pmax(scorePos,scoreNeg) #so that R does not overflow when taking exponential
  expScorePos<-exp(scorePos-m)
  expScoreNeg<-exp(scoreNeg-m)   #Exponentiate to get back to probabilities
  expScorePos/(expScorePos+expScoreNeg)    #Scale to the sum of one 
}
#Now apply to make predictions for selected sets
pVars<-paste("pred",c(numericVars,catVars),sep="") #For all variables
#pVars<-selVars #Only for variables selected in the previous sections
dTrain$nbpredl<-nBayes(pPos,dTrain[,pVars])
dCal$nbpredl<-nBayes(pPos,dCal[,pVars])
dTest$nbpredl<-nBayes(pPos,dTest[,pVars])

print(calcAUC(dTrain$nbpredl,dTrain[,outcome]))
print(calcAUC(dCal$nbpredl,dCal[,outcome]))
print(calcAUC(dTest$nbpredl,dTest[,outcome]))
